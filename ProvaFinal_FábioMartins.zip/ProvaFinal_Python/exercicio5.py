"""Exercício 5: contar carateres, maiúsculas, minúsculas e símbolos."""

def analisar_frase(frase):
    simbolos = "@#£$%&{}[]"
    carateres = sum(1 for c in frase if c != " ")
    maiusculas = sum(1 for c in frase if c.isupper())
    minusculas = sum(1 for c in frase if c.islower() and c not in "ºª")
    segundo_plano = sum(1 for c in frase if c in simbolos)
    return carateres, maiusculas, minusculas, segundo_plano

def main():
    frase = input("Introduza uma frase: ")
    carateres, maiusculas, minusculas, simbolos = analisar_frase(frase)
    print(f"Carateres sem espaços: {carateres}")
    print(f"Letras maiúsculas: {maiusculas}")
    print(f"Letras minúsculas (excluindo º e ª): {minusculas}")
    print(f"Símbolos de segundo plano: {simbolos}")

if __name__ == "__main__":
    main()
