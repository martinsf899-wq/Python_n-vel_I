"""Exercício 3: substituir uma sequência numa string."""

def main():
    frase = input("Introduza uma frase: ")
    antiga = input("Sequência a substituir: ")
    while antiga == "":
        print("A sequência a substituir não pode estar vazia.")
        antiga = input("Sequência a substituir: ")
    nova = input("Nova palavra ou sequência: ")
    # replace substitui todas as ocorrências, distinguindo maiúsculas e minúsculas.
    resultado = frase.replace(antiga, nova)
    print(f"Resultado: {resultado}")

if __name__ == "__main__":
    main()
