"""Exercício 1: calcular a idade pela fórmula pedida no enunciado."""

def main():
    nome = input("Nome: ")
    while True:
        try:
            ano = int(input("Ano de nascimento: "))
            if 1 <= ano <= 2025:
                break
            print("Introduza um ano entre 1 e 2025.")
        except ValueError:
            print("Introduza um ano inteiro.")
    idade = 2025 - ano
    print(f"{nome}, a sua idade, calculada com o ano 2025, é {idade} anos.")

if __name__ == "__main__":
    main()
