"""Exercício 4: gerar dez números e apresentar apenas os ímpares."""
from random import randint

def main():
    numeros = [randint(0, 10) for _ in range(10)]
    impares = [numero for numero in numeros if numero % 2 != 0]
    # O asterisco passa cada número como argumento; print separa-os por espaços.
    print(*impares)

if __name__ == "__main__":
    main()
