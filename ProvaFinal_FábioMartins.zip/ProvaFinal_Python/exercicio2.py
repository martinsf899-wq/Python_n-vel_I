"""Exercício 2: validar a nota e classificar o aluno."""

def classificar(nota):
    if not 0 <= nota <= 100:
        raise ValueError("A nota deve estar entre 0 e 100.")
    if nota <= 49:
        return "Insuficiente"
    if nota <= 75:
        return "Bom"
    return "Muito Bom"

def main():
    nome = input("Nome do aluno: ")
    while True:
        try:
            nota = int(input("Nota (inteiro de 0 a 100): "))
            classificacao = classificar(nota)
            break
        except ValueError:
            print("Nota inválida. Introduza um número inteiro entre 0 e 100.")
    print(f"{nome} obteve a nota {nota} e a classificação {classificacao}.")

if __name__ == "__main__":
    main()
